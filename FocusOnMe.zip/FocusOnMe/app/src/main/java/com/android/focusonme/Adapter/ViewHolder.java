package com.android.focusonme.Adapter;

import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

public class ViewHolder{
    TextView textInListView,extra;
    ImageView imageInListView;
    ConstraintLayout cs;
}